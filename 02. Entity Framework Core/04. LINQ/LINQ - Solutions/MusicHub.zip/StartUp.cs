﻿namespace MusicHub
{
    using System;

    using Data;
    using Initializer;
    using MusicHub.Data.Models;

    public class StartUp
    {
        public static void Main()
        {
            MusicHubDbContext context =
                new MusicHubDbContext();

            DbInitializer.ResetDatabase(context);

            
        }

        public static string ExportAlbumsInfo(MusicHubDbContext context, int producerId)
        {
            var producer = context.Producers.FirstOrDefault(p => p.Id == producerId);

            if (producer == null)
            {
                return $"Producer with ID {producerId} does not exist.";
            }

            var albums = context.Albums
                .Where(a => a.ProducerId == producerId)
                .Select(a => new
                {
                    AlbumName = a.Name,
                    ReleaseDate = a.ReleaseDate.ToString("MM/dd/yyyy"),
                    ProducerName = a.Producer.Name,
                    Songs = a.Songs
                        .OrderByDescending(s => s.Name)
                        .ThenBy(s => s.Writer.Name)
                        .Select(s => new
                        {
                            SongName = s.Name,
                            Price = s.Price.ToString("F2"),
                            WriterName = s.Writer.Name
                        })
                        .ToList(),
                    TotalPrice = a.Price.ToString("F2")
                })
                .OrderByDescending(a => decimal.Parse(a.TotalPrice))
                .ToList();

            var result = $"Albums produced by {producer.Name}:{Environment.NewLine}";

            foreach (var album in albums)
            {
                result += $"- Album name: {album.AlbumName}{Environment.NewLine}";
                result += $"  Release date: {album.ReleaseDate}{Environment.NewLine}";
                result += $"  Producer: {album.ProducerName}{Environment.NewLine}";
                result += $"  Songs:{Environment.NewLine}";

                foreach (var song in album.Songs)
                {
                    result += $"    - Song name: {song.SongName}{Environment.NewLine}";
                    result += $"      Price: {song.Price}{Environment.NewLine}";
                    result += $"      Writer: {song.WriterName}{Environment.NewLine}";
                }

                result += $"  Total album price: {album.TotalPrice}{Environment.NewLine}{Environment.NewLine}";
            }

            return result.TrimEnd();
        }

        public static string ExportSongsAboveDuration(MusicHubDbContext context, int duration)
        {
            var songs = context.Songs
            .Where(s => s.Duration > duration)
            .OrderBy(s => s.Name)
            .ThenBy(s => s.Writer.Name)
            .Select(s => new
            {
                SongName = s.Name,
                Performers = s.SongPerformers
                    .OrderBy(p => p.Performer.FirstName)
                    .ThenBy(p => p.Performer.LastName)
                    .Select(p => $"{p.Performer.FirstName} {p.Performer.LastName}")
                    .ToList(),
                WriterName = s.Writer.Name,
                AlbumProducer = s.Album.Producer.Name,
                Duration = TimeSpan.FromSeconds(s.Duration).ToString("c")
            })
            .ToList();

            var result = string.Empty;

            foreach (var song in songs)
            {
                result += $"- Song name: {song.SongName}{Environment.NewLine}";

                if (song.Performers.Any())
                {
                    result += $"  Performers: {string.Join(", ", song.Performers)}{Environment.NewLine}";
                }

                result += $"  Writer: {song.WriterName}{Environment.NewLine}";
                result += $"  Album Producer: {song.AlbumProducer}{Environment.NewLine}";
                result += $"  Duration: {song.Duration}{Environment.NewLine}{Environment.NewLine}";
            }

            return result.TrimEnd();

        }
    }
}
