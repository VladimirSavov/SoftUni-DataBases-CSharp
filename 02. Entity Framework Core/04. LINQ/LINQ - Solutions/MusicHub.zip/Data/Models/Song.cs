﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MusicHub.Data.Models.Enums;

namespace MusicHub.Data.Models
{
    public class Song
    {
        public Song()
        {
            this.SongPerformers = new HashSet<SongPerformer>();
            this.Performers = new HashSet<Performer>();
        }
        [Key]
        public int Id { get; set; }
        [MaxLength(20)]
        [Required]
        public string Name { get; set; }
        [Required]
        public TimeSpan Duration { get; set; }
        [Required]
        public DateTime CreatedOn { get; set; }
        [Required]
        public genreEnum Genre { get; set; }
        [ForeignKey("Album")]
        public int AlbumId { get; set; }
        public string Album { get; set; }
        [ForeignKey("Writer")]
        [Required]
        public int WriterId { get; set; }
        public string Writer { get; set; }
        [Required]
        public decimal Price { get; set; }
        public ICollection<SongPerformer> SongPerformers { get; set; }
        public ICollection<Performer> Performers { get; set; }
    }
}
